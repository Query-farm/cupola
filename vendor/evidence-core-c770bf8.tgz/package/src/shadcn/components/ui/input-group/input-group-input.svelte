<script lang="ts">
	import { cn } from '../../../../shadcn/utils.js';
	import type { ComponentProps } from 'svelte';
	import { Input } from '../../../../shadcn/components/ui/input/index.js';

	let {
		ref = $bindable(null),
		value = $bindable(),
		class: className,
		...props
	}: ComponentProps<typeof Input> = $props();
</script>

<Input
	bind:ref
	data-slot="input-group-control"
	class={cn(
		'flex-1 rounded-none border-0 bg-transparent shadow-none focus-visible:ring-0 dark:bg-transparent',
		className
	)}
	bind:value
	{...props}
/>
